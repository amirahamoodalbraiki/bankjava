package com.training.spring;

public class Account {
 	private String accountNumber;
	private double balance;
	private String accountType;
	
	public Account() {
		super();
	}
	
	public Account(String accountNumber, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public String accountDetails() {
		return "Account Number: " + accountNumber + ", Balance: " + balance + ", Account Type: " + accountType;
	}
	
}
