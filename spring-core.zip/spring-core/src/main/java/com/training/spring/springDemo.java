package com.training.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.spring.config.AppConfig;

public class springDemo {

	public static void main(String[] args) {
		//ApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Customer customer1 =(Customer)context.getBean(Customer.class);
	//	System.out.println("Customer Email: "+customer1.getEmail()+ ", "+ "Customer Age: "+customer1.getAge());
		System.out.println("Customer Email: "+customer1.customerDetails());
		
		
		//Customer customer2 =(Customer)context.getBean("customerld");
	//	customer2.setEmail("test@mail.com");
	//	System.out.println("Customer Email: "+customer2.getEmail());

	}

}
